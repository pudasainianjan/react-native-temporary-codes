import axios from 'axios';

export default axios.create({
  baseURL: 'http://77e3a885c7cb.ngrok.io',
});
